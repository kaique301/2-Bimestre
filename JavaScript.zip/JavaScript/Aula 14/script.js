let InputUm = document.querySelector("#InputUm");
let Resultado = document.querySelector("#Resultado");
let BrResultado = document.querySelector("#BrResultado");

function verificar(){
    let Num1 = Number(InputUm.value);

     if (Num1 % 2 == 0){
        Resultado.textContent = " é Par";
     } else {
        Resultado.textContent = "É impar";
     } 
}

BrResultado.onclick = function(){
    verificar();
}