let Real = document.querySelector("#Real");

let BrResultado = document.querySelector("#BrResultado");

let ResultadoA = document.querySelector("#ResultadoA");
let ResultadoB = document.querySelector("#ResultadoB");
let ResultadoC = document.querySelector("#ResultadoC");
let ResultadoD = document.querySelector("#ResultadoD");

function Cotacao(){

    let Num1 = Number(Real.value);

    ResultadoA.textContent = (Num1 * 1) / 100 + Num1;
    ResultadoB.textContent = (Num1 * 2) / 100 + Num1;
    ResultadoC.textContent = (Num1 * 5) / 100 + Num1;
    ResultadoD.textContent = (Num1 * 10) / 100 + Num1;

}

BrResultado.onclick = function(){
    Cotacao()
}