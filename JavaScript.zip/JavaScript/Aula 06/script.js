let NumeroUm = document.querySelector("#NumeroUm");
let NumeroDois = document.querySelector("#NumeroDois");
let NumeroTres = document.querySelector("#NumeroTres");
let ResultadoA = document.querySelector("#ResultadoA");
let ResultadoB = document.querySelector("#ResultadoB");
let ResultadoC = document.querySelector("#ResultadoC");
let ResultadoD = document.querySelector("#ResultadoD");

let BrResultado = document.querySelector("#BrResultado");

// exercio A
function SomaUm(){
    let num1 = Number(NumeroUm.value);
    let num2 = Number(NumeroDois.value);
    let num3 = Number(NumeroTres.value);
    let resultadoA = (num1 + num2 + num3)/ 3;

    ResultadoA.textContent = "media aritimetica " + resultadoA // media aritimetica

    return resultadoA;
}

// exercio B
function SomaDois(){
    let num1 = Number(NumeroUm.value);
    let num2 = Number(NumeroDois.value);
    let num3 = Number(NumeroTres.value);
    let ResultB = (num1 * 3) + (num2 * 2) + (num3 * 5) / 10

    ResultadoB.textContent = "media Ponderada " + ResultB

    return ResultB
}
// exercio C
function SomaTres(){
    let resultC = (SomaUm()) + (SomaDois())

    ResultadoC.textContent= "soma das duas médias " + resultC

    return resultC
}

// exercio D
function SomaQuatro(){
    
    ResultadoD.textContent = "media das media " + (SomaTres()) / 2;
}

BrResultado.onclick = function(){
    SomaUm()
    SomaDois()
    SomaTres()
    SomaQuatro()
}

// let media = SomaUm() = SomaDois;




