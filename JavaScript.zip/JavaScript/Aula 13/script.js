let InputUm = document.querySelector("#InputUm");
let InputDois = document.querySelector("#InputDois");
let InputTres = document.querySelector("#InputTres");
let InputQuatro = document.querySelector("#InputQuatro");
let Resultado = document.querySelector("#Resultado");
let BrResultado = document.querySelector("#BrResultado");

function verificar(){
    let Num1 = Number(InputUm.value);
    let Num2 = Number(InputDois.value);
    let Num3 = Number(InputTres.value);
    let Num4 = Number(InputQuatro.value);


    if((Num1 < Num2) && (Num1 < Num3) && (Num1 < Num4)){
        Resultado.textContent = Num1 + " Esse é Menor"
    } else if ((Num2 < Num1) && (Num2 < Num3) && (Num2 < Num4)){
        Resultado.textContent = Num2 + " Esse é Menor"
    } else if ((Num3 < Num1) && (Num3< Num2) && (Num3 < Num4)){
        Resultado.textContent = Num3 + " Esse é Menor"
    } else{
        Resultado.textContent = Num4 + " Esse é Menor"
    }

}

BrResultado.onclick = function(){
    verificar();

}