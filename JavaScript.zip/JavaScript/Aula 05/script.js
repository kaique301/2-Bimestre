let ValorUm = document.querySelector("#ValorUm");
let Resultado = document.querySelector("#Resultado");
let Aqui = document.querySelector("#Aqui");

function somar(){
    let num1 = Number(ValorUm.value);
    
    Resultado.textContent = (num1 * 1) /100 + num1;
    //Resultado.textContent = (((num1 * (1/100)) + num1;) mais Correto
}

Aqui.onclick = function(){
    somar()
}