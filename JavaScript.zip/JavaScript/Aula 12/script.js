let InputUm = document.querySelector("#InputUm");
let InputDois = document.querySelector("#InputDois");
let Resultado = document.querySelector("#Resultado");
let BrResultado = document.querySelector("#BrResultado");

function verificar(){
    let Num1 = Number(InputUm.value);
    let Num2 = Number(InputDois.value);

    if(Num1 > Num2){
        Resultado.textContent = Num1 + " Esse é Maior"
    } else if(Num2 > Num1){
        Resultado.textContent = Num2 + " Esse é Maior"
    }
}

BrResultado.onclick = function(){
    verificar();

}