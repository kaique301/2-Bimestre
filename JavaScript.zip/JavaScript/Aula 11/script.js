let InputUm = document.querySelector("#InputUm");
let InputDois = document.querySelector("#InputDois");
let Resultado = document.querySelector("#Resultado");
let BrResultado = document.querySelector("#BrResultado");

function Verificar(){
    let num1 = Number(InputUm.value);
    let num2 = Number(InputDois.value);
    let media = (num1 + num2) / 2;

    // media 6 ou maior = aprovado; media menor que 6 = reprovado
    
    if (media >= 6.0){
        Resultado.textContent = "Parabens vc conseguiu!!"
    } else{
        Resultado.textContent = "Tente Novamente mais tarde"
        
    }


}

BrResultado.onclick = function(){
    Verificar();
}